# Managing Undo History with Actions

More information on wiki page:

https://github.com/viliusle/miniPaint/wiki/Undo-Redo-system