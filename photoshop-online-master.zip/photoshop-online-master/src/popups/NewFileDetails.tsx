import React from "react";
import styled from "styled-components";

const Details = styled.div`
  height: 60rem;
  width: 30rem;
`;

const NewFileDetails = () => {
  return <Details></Details>;
};

export default NewFileDetails;
