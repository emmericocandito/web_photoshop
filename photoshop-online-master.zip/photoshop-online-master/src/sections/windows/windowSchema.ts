const windows: string[][] = [
  ["Color", "Swatches", "Gradients", "Patterns"],
  ["Properties", "Adjustments"],
  ["Layers", "Channels", "Paths"],
];

export default windows;
