# Security Policy

## Reporting a Vulnerability

If you have found a security vulnerability with Photoshop Online, please do not create an Issue for it.  Instead please contact Chase Manning directly on any of the socails on [his GitHub profile](https://github.com/chase-manning).
